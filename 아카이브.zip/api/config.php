<?php
/**
 * FinEdu — 실제 DB 설정 (gitignore 됨)
 *
 * 이 파일은 절대 커밋되지 않는다. InfinityFree 서버에 직접 업로드한다.
 */

return [
    'db' => [
        'host'     => 'sql301.infinityfree.com',
        'name'     => 'if0_41279101_finedu',
        'user'     => 'if0_41279101',
        'password' => 'XLUu7lPfdDdrV',
        'charset'  => 'utf8mb4',
    ],

    'session' => [
        'name'     => 'finedu_session',
        'lifetime' => 60 * 60 * 24 * 30,
        'secure'   => false,
        'samesite' => 'Lax',
    ],

    'password' => [
        'algo' => PASSWORD_BCRYPT,
        'cost' => 11,
    ],

    'debug' => false,
];
